import React from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import MasterWalletContract from './contracts/MasterWallet.json';
import getWeb3 from './utils/getWeb3';
import './App.css';

import ChildWalletForm from './components/ChildWalletForm';
import ChildWalletList from './components/ChildWalletList';
import Login from './components/Login';
import Register from './components/Register';
import TransactionForm from './components/TransactionForm';
import TransactionList from './components/TransactionList';

class App extends React.Component {
  state = { web3: null, accounts: null, contract: null };

  componentDidMount = async () => {
    try {
      // Get network provider and web3 instance.
      const web3 = await getWeb3();

      // Use web3 to get the user's accounts.
      const accounts = await web3.eth.getAccounts();

      // Get the contract instance.
      const networkId = await web3.eth.net.getId();
      const deployedNetwork = MasterWalletContract.networks[networkId];
      const instance = new web3.eth.Contract(
        MasterWalletContract.abi,
        deployedNetwork && deployedNetwork.address,
      );

      this.setState({ web3, accounts, contract: instance });
    } catch (error) {
      // Catch any errors for any of the above operations.
      alert(
        `Failed to load web3, accounts, or contract. Check console for details.`,
      );
      console.error(error);
    }
  };

  render() {
    if (!this.state.web3) {
      return <div>Loading Web3, accounts, and contract...</div>;
    }
    return (
      <Router>
        <div className="App">
          <nav>
            <ul>
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <Link to="/login">Login</Link>
              </li>
              <li>
                <Link to="/register">Register</Link>
              </li>
              <li>
                <Link to="/child-wallets">Child Wallets</Link>
              </li>
              <li>
                <Link to="/transactions">Transactions</Link>
              </li>
            </ul>
          </nav>
          <Switch>
            <Route exact path="/">
              <h1>Home Page</h1>
            </Route>
            <Route path="/login">
              <Login />
            </Route>
            <Route path="/register">
              <Register />
            </Route>
            <Route path="/child-wallets">
              <ChildWalletList web3={this.state.web3} contract={this.state.contract} accounts={this.state.accounts} />
              <ChildWalletForm web3={this.state.web3} contract={this.state.contract} accounts={this.state.accounts} />
            </Route>
            <Route path="/transactions">
              <TransactionList web3={this.state.web3} contract={this.state.contract} accounts={this.state.accounts} />
              <TransactionForm web3={this.state.web3} contract={this.state.contract} accounts={this.state.accounts} />
            </Route>
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;
